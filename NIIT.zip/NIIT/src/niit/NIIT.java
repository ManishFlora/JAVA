package niit;

import java.util.Scanner;

public class NIIT 
{
    public static void main(String[] args) 
    {
        MRClerk m = new MRClerk();
        Faculty f = new Faculty();
        GroupLeader g = new GroupLeader();
        CenterHead c = new CenterHead();
        int a;
        Scanner sc = new Scanner(System.in);
        System.out.println("1. MRClerk");
        System.out.println("2. Faculty");
        System.out.println("3. GroupLeader");
        System.out.println("4. CenterHead");
        System.out.println("5. Exit");
        a = sc.nextInt();
        switch(a)
        {
            case 1:
                m.getinfo();
                m.showinfo();
                break;
                case 2:
                f.getinfo();
                f.showinfo();
                break;
                case 3:
                g.getinfo();
                g.showinfo();
                break;
                case 4:
                c.getinfo();
                c.showinfo();
                break;
                case 5:
                    System.exit(0);
                default:
                    System.out.println("Invalid Input");
                    break;
        }
    }
}
