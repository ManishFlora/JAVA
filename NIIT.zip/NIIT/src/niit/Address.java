package niit;

import java.util.Scanner;

public class Address 
{
    Scanner sc=new Scanner(System.in);
    String street, city, state;
    
    public void getinfo()
    {
        System.out.println("Enter Your Street");
        street=sc.next();
        System.out.println("Enter Your City");
        city=sc.next();
        System.out.println("Enter Your State");
        state=sc.next();
    }
    
    public void showinfo()
    {
        System.out.println("Your Address is: "+street);
        System.out.println("Your Address is: "+city);
        System.out.println("Your Address is: "+state);
    }
}
