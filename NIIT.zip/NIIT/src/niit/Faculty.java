package niit;

public class Faculty extends Employee
{
    int noofStudents;
    String batchTimings;
    String courseName;
    
    public void getinfo()
    {
        super.getinfo();
        System.out.println("Enter The No Of Students:");
        noofStudents=sc.nextInt();
        System.out.println("Enter The Course Name");
        courseName=sc.next();
        System.out.println("Enter The Batch Timings");
        batchTimings=sc.next();
    }
    
    public void showinfo()
    {
        super.showinfo();
        System.out.println("The No Of Students is: "+noofStudents);
        System.out.println("The Course Name is: "+courseName);
        System.out.println("The Batch Timings are: "+batchTimings);
    }
}
