package niit;

public class MRClerk extends Employee
{
    int noofStudents;
    int tasksAssigned;
    
    public void getinfo()
    {
        super.getinfo();
        System.out.println("Enter The No Of Students:");
        noofStudents=sc.nextInt();
        System.out.println("Enter The No Of Tasks Assigned");
        tasksAssigned=sc.nextInt();
    }
    
    public void showinfo()
    {
        super.showinfo();
        System.out.println("The No Of Students is: "+noofStudents);
        System.out.println("The No Of Tasks Assigned is: "+tasksAssigned);
    }
}
