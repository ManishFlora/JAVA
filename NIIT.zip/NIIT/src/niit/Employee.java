package niit;

import java.util.Scanner;

public class Employee 
{
    String fname, lname, gender, email;
    int age;
    Scanner sc=new  Scanner(System.in);
    Address ad = new Address();
    
    public void getinfo()
    {
        System.out.println("Enter First Name");
        fname=sc.next();
        System.out.println("Enter Last Name");
        lname=sc.next();
        System.out.println("Enter Your Gender");
        gender=sc.next();
        System.out.println("Enter Your Email");
        email=sc.next();
        System.out.println("Enter Your Age");
        age=sc.nextInt();
        ad.getinfo();
    }
    
    public void showinfo()
    {
        System.out.println("Your First Name is: "+fname);
        System.out.println("Your Last Name is: "+lname);
        System.out.println("Your Gender is: "+gender);
        System.out.println("Your Email is: "+email);
        System.out.println("Your Age is: "+age);
        ad.showinfo();
    }
}

