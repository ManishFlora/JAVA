package niit;

public class CenterHead extends Employee
{
    @Override
    public void getinfo()
    {
        super.getinfo();
    }
    
    @Override
    public void showinfo()
    {
        super.showinfo();
    }
}
