package niit;

public class GroupLeader extends Employee
{
    int noofMR,noofCR,batchesLaunched;
    
    
    public void getinfo()
    {
        super.getinfo();
        System.out.println("Enter The No Of Batches Launched:");
        batchesLaunched=sc.nextInt();
        System.out.println("Enter The No Of MR");
        noofMR=sc.nextInt();
        System.out.println("Enter The No Of CR");
        noofCR=sc.nextInt();
    }
    
    public void showinfo()
    {
        super.showinfo();
        System.out.println("The No Of Batches Launched is: "+batchesLaunched);
        System.out.println("The No Of MR is: "+noofMR);
        System.out.println("The No Of CR is: "+noofCR);
    }
}
